sap.ui.define([
	"de/mindsquare/zph_Thesis/test/unit/controller/App.controller"
], function () {
	"use strict";
});