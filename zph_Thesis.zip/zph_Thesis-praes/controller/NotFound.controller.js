sap.ui.define([
	//	"sap/ui/core/mvc/Controller"
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("de.mindsquare.zph_Thesis.controller.NotFound", {

		onInit: function () {

		},

	});

});